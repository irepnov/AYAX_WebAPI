﻿using AutoMapper;
using DAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WebApp.Repository;
using WebApp.ViewModel;

namespace WebApp.Controllers
{
    [Produces("application/json")]
    [Route("api/Division")]
    [Authorize]
    public class DivisionController : Controller
    {
        IDivRepository realRepository;
        public DivisionController(IDivRepository _realRepository) => realRepository = _realRepository;

        [HttpGet]
        [Route("GetPageDivisions")]
        public async Task<IActionResult> GetPageDivisions(int? DivisionID, int? pageIndex, int pageSize = 2, string Name = null)
        {
            var obj = await realRepository.GetPageDivisions(DivisionID, Name, pageIndex, pageSize);
            if (obj == null)
            {
                return BadRequest();
            }

            return Ok(obj);
        }

        [HttpPost]
        [Route("AddDivision")]
        public async Task<IActionResult> AddDivision([FromBody]DivisionView model)
        {
            if (ModelState.IsValid)
            {
                Mapper.Initialize(cfg => cfg.CreateMap<DivisionView, Division>()
                    .ForMember("Name", opt => opt.MapFrom(c => c.NameDivision))
                    .ForMember("CreatedDateTime", opt => opt.MapFrom(src => src.CreatedDate)));
                // Выполняем сопоставление
                Division div = Mapper.Map<DivisionView, Division>(model);

                var realtId = await realRepository.AddDivision(div);
                if (realtId > 0)
                {
                    return Ok(realtId);
                }
                else
                {
                    return BadRequest();
                }
            }

            return BadRequest();
        }

        [HttpDelete("{id}")]
        [Route("DeleteDivision/{id}")]
        public async Task<IActionResult> DeleteDivision(int id)
        {
            var realtId = await realRepository.DeleteDivision(id);
            if (realtId > 0)
            {
                return Ok(realtId);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut]
        [Route("UpdateDivision")]
        public async Task<IActionResult> UpdateDivision([FromBody]Division model)
        {
            if (ModelState.IsValid)
            {
                await realRepository.UpdateDivision(model);
                return Ok();
            }

            return BadRequest();
        }
    }

}