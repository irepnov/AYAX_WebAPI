﻿using DAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WebApp.Repository;

namespace WebApp.Controllers
{
    [Produces("application/json")]
    [Route("api/Division")]
    [Authorize]
    public class DivisionController : Controller
    {
        IDivRepository realRepository;
        public DivisionController(IDivRepository _realRepository) => realRepository = _realRepository;

        [HttpGet]
        [Route("GetPageDivisions")]
        public async Task<IActionResult> GetPageDivisions(int? DivisionID, int? pageIndex, int pageSize = 2, string Name = null)
        {
            var obj = await realRepository.GetPageDivisions(DivisionID, Name, pageIndex, pageSize);
            if (obj == null)
            {
                return BadRequest();
            }

            return Ok(obj);
        }

        [HttpPost]
        [Route("AddDivision")]
        public async Task<IActionResult> AddDivision([FromBody]Division model)
        {
            if (ModelState.IsValid)
            {
                var realtId = await realRepository.AddDivision(model);
                if (realtId > 0)
                {
                    return Ok(realtId);
                }
                else
                {
                    return BadRequest();
                }
            }

            return BadRequest();
        }

        [HttpDelete("{id}")]
        [Route("DeleteDivision/{id}")]
        public async Task<IActionResult> DeleteDivision(int id)
        {
            var realtId = await realRepository.DeleteDivision(id);
            if (realtId > 0)
            {
                return Ok(realtId);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut]
        [Route("UpdateDivision")]
        public async Task<IActionResult> UpdateDivision([FromBody]Division model)
        {
            if (ModelState.IsValid)
            {
                await realRepository.UpdateDivision(model);
                return Ok();
            }

            return BadRequest();
        }
    }

}