﻿using DAL;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WebApp.Repository;

namespace WebApp.Controllers
{
    [Produces("application/json")]
    [Route("api/Realtor")]
    public class RealtorController : Controller
    {
        IRealtRepository realRepository;
        public RealtorController(IRealtRepository _realRepository) => realRepository = _realRepository;

        [HttpGet]
        [Route("GetPageRealtors")]
        public async Task<IActionResult> GetPageRealtors(int? RealtorID, int? DivisionID, int? pageIndex, int pageSize = 5, string LastName = null, string DivisionName = null)
        {
            var obj = await realRepository.GetPageRealtors(RealtorID, DivisionID, LastName, DivisionName, pageIndex, pageSize);
            if (obj == null)
            {
                return BadRequest();
            }

            return Ok(obj);
        }

        [HttpPost]
        [Route("AddRealtor")]
        public async Task<IActionResult> AddRealtor([FromBody]Realtor model)
        {
            if (ModelState.IsValid)
            {
                var realtId = await realRepository.AddRealtor(model);
                if (realtId > 0)
                {
                    return Ok(realtId);
                }
                else
                {
                    return BadRequest();
                }
            }

            return BadRequest();
        }

        [HttpDelete("{id}")]
        [Route("DeleteRealtor/{id}")]
        public async Task<IActionResult> DeleteRealtor(int id)
        {
            var realtId = await realRepository.DeleteRealtor(id);
            if (realtId > 0)
            {
                return Ok(realtId);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut]
        [Route("UpdateRealtor")]
        public async Task<IActionResult> UpdateRealtor([FromBody]Realtor model)
        {
            if (ModelState.IsValid)
            {
                await realRepository.UpdateRealtor(model);
                return Ok();
            }

            return BadRequest();
        }
    }

}