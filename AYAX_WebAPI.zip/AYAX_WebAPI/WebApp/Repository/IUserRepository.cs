﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp.Repository
{
    public interface IUserRepository
    {
        Task<User> GetUser(string Login, string Password);
    }
}
