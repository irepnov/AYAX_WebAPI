﻿using DAL;
using System.Threading.Tasks;
using WebApp.ViewModel;

namespace WebApp.Repository
{
    public interface IDivRepository
    {
        Task<PaginatedList<Division>> GetPageDivisions(int? DivisionID, string Name, int? pageIndex, int pageSize);
        Task<int> AddDivision(Division objR);
        Task<int> DeleteDivision(int DivisionID);
        Task UpdateDivision(Division objR);
    }
}
