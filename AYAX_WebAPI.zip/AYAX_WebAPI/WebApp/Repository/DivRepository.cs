﻿using DAL;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using WebApp.ViewModel;

namespace WebApp.Repository
{
    public class DivRepository : IDivRepository
    {
        AYAXContext db;
        public DivRepository(AYAXContext _db) => db = _db;

        public async Task<int> AddDivision(Division objR)
        {
            if (db == null)
                return 0;

            await db.Divisions.AddAsync(objR);
            await db.SaveChangesAsync();

            return objR.Id;
        }

        public async Task<int> DeleteDivision(int DivisionID)
        {
            if (db == null)
                return 0;

            int rr = 0;
            var r = await db.Divisions.FirstOrDefaultAsync(x => x.Id == DivisionID);
            if (r != null)
            {
                rr = r.Id;
                db.Divisions.Remove(r);
                await db.SaveChangesAsync();
            }

            return rr;
        }

        public async Task<PaginatedList<Division>> GetPageDivisions(int? DivisionID, string Name, int? pageIndex, int pageSize)
        {
            if (db == null)
                return null;

            var source = from d in db.Divisions
                         where (
                                      ((Name != null && d.Name.Contains(Name)) || (Name == null))
                                      &&
                                      ((DivisionID != null && d.Id == DivisionID) || (DivisionID == null))
                               )
                         orderby d.Id
                         select d;

            return await PaginatedList<Division>.CreateAsync(source.AsNoTracking(), pageIndex ?? 1, pageSize);
        }

        public async Task UpdateDivision(Division objR)
        {
            if (db != null)
            {
                db.Divisions.Update(objR);
                await db.SaveChangesAsync();
            }
        }
    }
}
