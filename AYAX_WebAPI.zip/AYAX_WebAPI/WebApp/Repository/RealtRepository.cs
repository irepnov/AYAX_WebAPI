﻿using DAL;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using WebApp.ViewModel;

namespace WebApp.Repository
{
    public class RealtRepository : IRealtRepository
    {
        AYAXContext db;
        public RealtRepository(AYAXContext _db) => db = _db;

        public async Task<PaginatedList<RealtorView>> GetPageRealtors(int? RealtorID, int? DivisionID, string LastName, string DivisionName, int? pageIndex, int pageSize)
        {
            if (db == null)
                return null;

            var source = db.Realtors./*AsQueryable().*/Include(d => d.Division)
                          .Where(x =>
                                        ((LastName != null && x.Lastname.Contains(LastName)) || (LastName == null))
                                        &&
                                        ((RealtorID != null && x.Id == RealtorID) || (RealtorID == null))
                                        &&
                                        ((DivisionID != null && x.DivisionId == DivisionID) || (DivisionID == null))
                                        &&
                                        ((DivisionName != null && x.Division.Name == DivisionName) || (DivisionName == null))
                                 )
                          .OrderBy(r => r.Id)
                          .Select(r => new RealtorView { Id = r.Id, Firstname = r.Firstname, Lastname = r.Lastname, CreatedDateTime = r.CreatedDateTime, DivisionId = r.DivisionId, DivisionName = r.Division.Name });

            return await PaginatedList<RealtorView>.CreateAsync(source.AsNoTracking(), pageIndex ?? 1, pageSize);
        }

        public async Task<int> AddRealtor(Realtor objR)
        {
            if (db == null)
                return 0;

            await db.Realtors.AddAsync(objR);
            await db.SaveChangesAsync();

            return objR.Id;
        }

        public async Task<int> DeleteRealtor(int RealtorID)
        {
            if (db == null)
                return 0;

            int rr = 0;
            var r = await db.Realtors.FirstOrDefaultAsync(x => x.Id == RealtorID);
            if (r != null)
            {
                rr = r.Id;
                db.Realtors.Remove(r);
                await db.SaveChangesAsync();
            }

            return rr;
        }

        public async Task UpdateRealtor(Realtor objR)
        {
            if (db != null)
            {
                db.Realtors.Update(objR);
                await db.SaveChangesAsync();
            }
        }
    }
}
