﻿using DAL;
using System.Threading.Tasks;
using WebApp.ViewModel;

namespace WebApp.Repository
{
    public interface IRealtRepository
    {
        Task<PaginatedList<RealtorView>> GetPageRealtors(int? RealtorID, int? DivisionID, string LastName, string DivisionName, int? pageIndex, int pageSize);
        Task<int> AddRealtor(Realtor objR);
        Task<int> DeleteRealtor(int RealtorID);
        Task UpdateRealtor(Realtor objR);
    }
}
