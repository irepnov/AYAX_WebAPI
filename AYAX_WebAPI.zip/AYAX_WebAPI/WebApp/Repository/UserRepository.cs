﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL;
using Microsoft.EntityFrameworkCore;

namespace WebApp.Repository
{
    public class UserRepository : IUserRepository
    {
        AYAXContext db;
        public UserRepository(AYAXContext _db) => db = _db;
        public async Task<User> GetUser(string Login, string Password)
        {
            if (db == null)
                return null;

            return await (from d in db.Users
                             where d.Login == Login && d.Password == Password
                             select d).FirstAsync();
        }
    }
}
