﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Autofac.Extensions.DependencyInjection;
using Autofac;
using DAL;
using Microsoft.EntityFrameworkCore;
using WebApp.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace WebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            //подключение к БД через EF
            services.AddDbContext<AYAXContext>(opts => opts.UseSqlServer(Configuration["ConnectionString:AyaxDB"]));
            //аутентификация JWT
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                                        .AddJwtBearer(options =>
                                        {
                                            options.TokenValidationParameters = new TokenValidationParameters
                                            {
                                                ValidateIssuer = true,
                                                ValidateAudience = true,
                                                ValidateLifetime = true,
                                                ValidateIssuerSigningKey = true,
                                                ValidIssuer = Configuration["Jwt:Issuer"],
                                                ValidAudience = Configuration["Jwt:Issuer"],
                                                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                                            };
                                        });
            services.AddMvc();
//зависимости Autofac
            var builder = new ContainerBuilder();
            builder.RegisterType<RealtRepository>().As<IRealtRepository>(); //репозиторий риеэтор
            builder.RegisterType<DivRepository>().As<IDivRepository>(); //репозиторий подразделение
            builder.RegisterType<UserRepository>().As<IUserRepository>(); //репозиторий пользователи
            builder.Populate(services);

            var container = builder.Build();
            return new AutofacServiceProvider(container);
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetRequiredService<AYAXContext>();
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
            } //создание БД

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseAuthentication(); //использовать аутентификацию
            app.UseMvc();
        }
    }
}
