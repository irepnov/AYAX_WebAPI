﻿using System;

namespace WebApp.ViewModel
{
    public class RealtorView
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int? DivisionId { get; set; }
        public string DivisionName { get; set; }
    }
}
