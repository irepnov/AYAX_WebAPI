﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DAL
{
    public class AYAXContext : DbContext
    {
        public AYAXContext(DbContextOptions<AYAXContext> options)
                : base(options)
        {
        }

        public DbSet<Realtor> Realtors { get; set; }
        public DbSet<Division> Divisions { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Realtor>().ToTable("stRealtors"); //переименовать таблицу
            modelBuilder.Entity<Realtor>().Property(t => t.Id)
                .ValueGeneratedOnAdd()
                .HasColumnType("int")
                .IsRequired(); //переименовать поле таблицы
            modelBuilder.Entity<Realtor>().Property(t => t.Firstname)
                .HasColumnName("FirstName")
                .HasMaxLength(200)
                .HasColumnType("varchar(200)"); //явное указание типа
            modelBuilder.Entity<Realtor>().Property(t => t.Lastname)
                .HasMaxLength(200)
                .HasColumnType("varchar(200)");
            modelBuilder.Entity<Realtor>().Property(t => t.CreatedDateTime)
                .HasColumnType("datetime2")
                .HasColumnName("CD")
                .IsRequired();


            modelBuilder.Entity<Division>().ToTable("stDivisions"); //переименовать таблицу
            modelBuilder.Entity<Division>().Property(t => t.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("ID").IsRequired() //переименовать поле таблицы
                .HasColumnType("int");
            modelBuilder.Entity<Division>().Property(t => t.Name)
                .HasMaxLength(200)
                .HasColumnType("varchar(200)");
            modelBuilder.Entity<Division>().Property(t => t.CreatedDateTime)
                .HasColumnType("datetime2")
                .HasColumnName("CD")
                .IsRequired();


            modelBuilder.Entity<User>().ToTable("stUsers");
            modelBuilder.Entity<User>().Property(t => t.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("ID").IsRequired() //переименовать поле таблицы
                .HasColumnType("int");


            modelBuilder.Entity<Division>()
                .HasMany(c => c.Realtors)
                .WithOne(e => e.Division)
                .IsRequired();




            modelBuilder.Entity<Division>()
                 .HasData(
                         new Division() { Id = 1, Name = "podraz 1", CreatedDateTime = DateTime.Now },
                         new Division() { Id = 2, Name = "podraz 2", CreatedDateTime = DateTime.Now },
                         new Division() { Id = 3, Name = "podraz 3", CreatedDateTime = DateTime.Now }
                         );

            modelBuilder.Entity<Realtor>()
                 .HasData(
                         new Realtor() { Id = 1, Firstname = "real 1", Lastname = "real name1", DivisionId = 1, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 2, Firstname = "real 2", Lastname = "real name2", DivisionId = 1, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 3, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 4, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 5, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 6, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 7, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 8, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 9, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 10, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 11, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 12, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 13, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 14, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 15, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 16, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 17, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 18, Firstname = "real 3", Lastname = "real name3", DivisionId = 2, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 19, Firstname = "real 4", Lastname = "real name4", DivisionId = 3, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 20, Firstname = "real 4", Lastname = "real name4", DivisionId = 3, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 21, Firstname = "real 4", Lastname = "real name4", DivisionId = 3, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 22, Firstname = "real 4", Lastname = "real name4", DivisionId = 3, CreatedDateTime = DateTime.Now },
                         new Realtor() { Id = 23, Firstname = "real 4", Lastname = "real name4", DivisionId = 3, CreatedDateTime = DateTime.Now }
                         );

            modelBuilder.Entity<User>()
                .HasData(
                         new User() { Id = 1, Login = "111", Password = "111" },
                         new User() { Id = 2, Login = "222", Password = "222" }
                         );
        }

    }

}
